# API Reference — Sprint 2 Endpoints

## Learning Path (Mi Ruta)

### GET `/api/learning-path`
**Autenticación:** Bearer token (estudiante)  
**Descripción:** Obtiene la ruta personalizada con estados de desbloqueo.

**Respuesta (200):**
```json
[
  {
    "id": 1,
    "nombre": "Pubertad",
    "orden": 1,
    "progreso": {
      "completados": 1,
      "total": 3
    },
    "pasos": [
      {
        "id": 10,
        "tipo_paso": "publicacion",
        "publicacion_id": 5,
        "titulo": "Cambios en la pubertad",
        "slug": "cambios-pubertad",
        "orden": 1,
        "obligatorio": true,
        "estado": "COMPLETED"
      },
      {
        "id": 11,
        "tipo_paso": "actividad",
        "actividad_id": 3,
        "titulo": "Quiz: Hormonas",
        "orden": 2,
        "obligatorio": true,
        "estado": "AVAILABLE"
      }
    ]
  }
]
```

**Estados de paso:**
- `COMPLETED` — ya finalizado.
- `AVAILABLE` — listo para comenzar.
- `IN_PROGRESS` — intento abierto.
- `LOCKED` — bloqueado por prerequisito.

---

## Route Steps Management

### GET `/api/route-steps?categoria_id=1`
**Autenticación:** Docente  
**Descripción:** Lista pasos de un módulo.

**Query params:**
- `categoria_id` (int, requerido) — ID del módulo.

**Respuesta (200):**
```json
[
  {
    "id": 10,
    "categoria_id": 1,
    "tipo_paso": "publicacion",
    "publicacion_id": 5,
    "orden": 1,
    "obligatorio": true,
    "activo": true,
    "titulo": "Cambios en la pubertad"
  }
]
```

---

### POST `/api/route-steps`
**Autenticación:** Docente  
**Descripción:** Crea nuevo paso en una ruta.

**Body (application/json):**
```json
{
  "categoria_id": 1,
  "tipo_paso": "publicacion",
  "publicacion_id": 5,
  "obligatorio": true,
  "activo": true
}
```

O para actividad:
```json
{
  "categoria_id": 1,
  "tipo_paso": "actividad",
  "actividad_id": 3,
  "obligatorio": true,
  "activo": true
}
```

**Respuesta (201):**
```json
{
  "id": 12,
  "categoria_id": 1,
  "tipo_paso": "publicacion",
  "publicacion_id": 5,
  "orden": 2,
  "obligatorio": true,
  "activo": true,
  "titulo": "Cambios en la pubertad"
}
```

**Errores:**
- `400` — Validación fallida (contenido no existe, tipo_paso inválido).
- `403` — No autorizado (solo docente/admin).

---

### PATCH `/api/route-steps/{id}`
**Autenticación:** Docente  
**Descripción:** Edita un paso existente.

**Body (application/json):**
```json
{
  "obligatorio": false,
  "activo": false
}
```

**Respuesta (200):**
```json
{
  "id": 10,
  "categoria_id": 1,
  "tipo_paso": "publicacion",
  "publicacion_id": 5,
  "orden": 1,
  "obligatorio": false,
  "activo": false
}
```

---

### DELETE `/api/route-steps/{id}`
**Autenticación:** Docente  
**Descripción:** Elimina un paso.

**Respuesta (204):** (sin cuerpo)

---

### POST `/api/route-steps/reorder`
**Autenticación:** Docente  
**Descripción:** Reordena pasos en un módulo.

**Body (application/json):**
```json
{
  "categoria_id": 1,
  "ordered_ids": [11, 10, 12]
}
```
(Nuevas posiciones: paso 11 primero, 10 segundo, 12 tercero.)

**Respuesta (200):**
```json
[
  {
    "id": 11,
    "categoria_id": 1,
    "tipo_paso": "actividad",
    "actividad_id": 3,
    "orden": 1,
    "obligatorio": true,
    "activo": true
  },
  {
    "id": 10,
    "categoria_id": 1,
    "tipo_paso": "publicacion",
    "publicacion_id": 5,
    "orden": 2,
    "obligatorio": true,
    "activo": true
  }
]
```

**Errores:**
- `400` — Lista incompleta o IDs no pertenecen al módulo.

---

## Tags

### GET `/api/tags`
**Autenticación:** No requerida  
**Descripción:** Lista todas las etiquetas disponibles.

**Respuesta (200):**
```json
[
  {
    "id": 1,
    "nombre": "Laboratorio"
  },
  {
    "id": 2,
    "nombre": "Refuerzo"
  }
]
```

---

### POST `/api/tags`
**Autenticación:** Docente  
**Descripción:** Crea nueva etiqueta (idempotente, case-insensitive).

**Body (application/json):**
```json
{
  "nombre": "Grupo 10B"
}
```

**Respuesta (201):**
```json
{
  "id": 3,
  "nombre": "Grupo 10B"
}
```

**Nota:** Si la etiqueta ya existe (sin distinguir mayúsculas), devuelve la existente con (200).

---

### GET `/api/publications/{id}/tags`
**Autenticación:** No requerida  
**Descripción:** Obtiene etiquetas de una publicación.

**Respuesta (200):**
```json
[
  {
    "id": 1,
    "nombre": "Laboratorio"
  }
]
```

---

### PUT `/api/publications/{id}/tags`
**Autenticación:** Docente/Autor  
**Descripción:** Asigna etiquetas a una publicación (reemplaza conjunto anterior).

**Body (application/json):**
```json
{
  "etiquetas": ["Laboratorio", "Refuerzo"]
}
```

**Respuesta (200):**
```json
[
  {
    "id": 1,
    "nombre": "Laboratorio"
  },
  {
    "id": 2,
    "nombre": "Refuerzo"
  }
]
```

**Errores:**
- `403` — No eres autor ni admin.
- `400` — Validación fallida (nombres vacíos, etc.).

---

## Settings (Admin)

### GET `/api/settings/feed-banner`
**Autenticación:** No requerida  
**Descripción:** Obtiene configuración del banner del feed.

**Respuesta (200):**
```json
{
  "image_url": "/uploads/banner-2024.jpg",
  "active": true
}
```

**Respuesta sin banner (200):**
```json
{
  "image_url": null,
  "active": false
}
```

---

### PUT `/api/settings/feed-banner`
**Autenticación:** Admin  
**Descripción:** Actualiza banner (URL y estado).

**Body (application/json):**
```json
{
  "image_url": "/uploads/nuevo-banner.jpg",
  "active": true
}
```

O solo cambiar estado:
```json
{
  "active": false
}
```

**Respuesta (200):**
```json
{
  "image_url": "/uploads/nuevo-banner.jpg",
  "active": false
}
```

**Errores:**
- `403` — No eres admin.

---

## Activities (Modificado)

### GET `/api/activities/{id}`
**Cambio en Sprint 2:** Ahora usa `actividad["motor_quiz"]` para decidir rama.

**Respuesta con motor='legacy':**
```json
{
  "id": 3,
  "titulo": "Quiz antiguo",
  "motor_quiz": "legacy",
  "preguntas": [
    {
      "id": 100,
      "tipo": "opcion_multiple",
      "enunciado": "¿Pregunta?",
      "opciones": ["A", "B", "C"],
      "respuesta_correcta": "A"
    }
  ]
}
```

**Respuesta con motor='unificado':**
```json
{
  "id": 4,
  "titulo": "Quiz moderno",
  "motor_quiz": "unificado",
  "quiz": {
    "id": 4,
    "version": 1,
    "estado": "publicado",
    "items": [
      {
        "id": "block-1",
        "type": "single_choice",
        "prompt": "¿Pregunta?",
        "options": [
          {
            "id": "opt-a",
            "text": "Opción A",
            "correct": true
          }
        ]
      }
    ]
  },
  "preguntas": [...],  // Alias de quiz.items para compatibilidad
  "items": [...]        // Alias de quiz.items para compatibilidad
}
```

---

## Frontend API Service Functions

Ubicadas en `frontend/src/services/api.js`:

### Learning Path
```javascript
api.getLearningPath()
  // GET /api/learning-path
  // Returns: Promise<Array<ModuloRuta>>

api.getRouteSteps(categoriaId)
  // GET /api/route-steps?categoria_id=
  // Returns: Promise<Array<PasoRuta>>

api.createRouteStep(data)
  // POST /api/route-steps
  // Returns: Promise<PasoRuta>

api.updateRouteStep(id, data)
  // PATCH /api/route-steps/{id}
  // Returns: Promise<PasoRuta>

api.deleteRouteStep(id)
  // DELETE /api/route-steps/{id}
  // Returns: Promise<void>

api.reorderRouteSteps(categoriaId, orderedIds)
  // POST /api/route-steps/reorder
  // Returns: Promise<Array<PasoRuta>>
```

### Tags
```javascript
api.getTags()
  // GET /api/tags
  // Returns: Promise<Array<Etiqueta>>

api.createTag(nombre)
  // POST /api/tags
  // Returns: Promise<Etiqueta>

api.setPublicationTags(publicationId, nombreEtiquetas)
  // PUT /api/publications/{id}/tags
  // Returns: Promise<Array<Etiqueta>>
```

### Settings
```javascript
api.getFeedBanner()
  // GET /api/settings/feed-banner
  // Returns: Promise<{image_url: string|null, active: bool}>

api.updateFeedBanner(imageUrl, active)
  // PUT /api/settings/feed-banner
  // Returns: Promise<{image_url: string|null, active: bool}>

api.uploadFeedBanner(file)
  // POST /api/uploads (multipart)
  // Returns: Promise<{url: string}>
```

---

## Status Codes

| Código | Significado |
|--------|-------------|
| 200 | OK |
| 201 | Created |
| 204 | No Content |
| 400 | Bad Request (validación fallida) |
| 401 | Unauthorized (token inválido o expirado) |
| 403 | Forbidden (no tienes permiso) |
| 404 | Not Found |
| 500 | Internal Server Error |

---

## Notas de compatibilidad

- Todos los endpoints nuevos son **additive** — no rompen endpoints existentes.
- Cambio en `GET /api/activities/{id}` es **backward-compatible**:
  - Legacy devuelve `preguntas` como antes.
  - Unificado devuelve `quiz` + `preguntas` (alias para compatibilidad).
- Los estados de paso (`LOCKED`/`AVAILABLE`/`IN_PROGRESS`/`COMPLETED`) se calculan **server-side** — el frontend solo los renderiza.
- Retirado endpoint muerto `obtener_ruta_aprendizaje` (sin consumidores).

