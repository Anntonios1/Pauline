# Sprint 2 — AulaRed Delivery Package

## 📦 Contents

This zip contains comprehensive documentation of Sprint 2 implementation for AulaRed platform.

### Files included:

1. **SPRINT2_CHANGES.md** — Complete feature breakdown across 8 phases
   - Database schema changes
   - Backend services and routes
   - Frontend components
   - Test coverage
   - Manual verification checklist

2. **API_REFERENCE.md** — Complete API endpoint documentation
   - All new endpoints (Learning Path, Tags, Settings)
   - Request/response examples
   - Status codes and error handling
   - Frontend API service functions

3. **README.md** — This file

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8+ (backend)
- Node.js 16+ (frontend)
- Git

### Setup

**1. Install dependencies:**
```bash
# Backend
pip install -r api/requirements.txt

# Frontend
cd frontend
npm install
```

**2. Start servers:**
```bash
# Terminal 1 — Backend (from repo root)
python -m uvicorn api.app:app --reload

# Terminal 2 — Frontend
cd frontend
npm run dev
```

**3. Access application:**
- Frontend: http://127.0.0.1:5173
- Backend API: http://127.0.0.1:8000
- Login: Use test credentials (ask team)

---

## ✨ Key Features Implemented

### 1. **Separación Feed ↔ Mi Ruta**
- New `ruta_pasos` table separates curated content from free feed
- Same publication/activity can appear in both surfaces independently
- Publications without `ruta_pasos` entry still visible in feed

### 2. **Sequential Unlocking System**
- Real server-side calculation of step states (LOCKED/AVAILABLE/IN_PROGRESS/COMPLETED)
- Reads from `intentos` (activity completion) and `eventos_aprendizaje` (publication reads)
- Prerequisite-based progression across module boundaries
- Optional steps don't block advancement

### 3. **Unified Quiz Engine**
- Explicit `motor_quiz` flag ('legacy' or 'unificado') eliminates heuristic guessing
- Simplifies `get_activity()` branching logic
- Backward compatible — legacy activities still work

### 4. **Teacher Route Management Panel**
- New UI at `/admin/mi-ruta` for CRUD of learning path steps
- Drag-to-reorder with visual feedback
- Add/edit/delete steps with full validation
- Live preview updates student's route

### 5. **One-Click Wordwall**
- Activities with single embedded iframe skip intermediate screen
- Reduces interaction steps for embedded interactive content (Wordwall, etc.)
- Multi-block activities retain intermediate screen for context

### 6. **Free-form Tags System**
- Case-insensitive tag creation
- Batch tag assignment to publications
- Visible as chips in feed cards
- Tag selector in publication creator

### 7. **Image Lightbox with Zoom**
- Click any image to open interactive viewer
- Zoom controls (±, percentage display, fit-to-window reset)
- Pan support when zoomed
- Keyboard shortcuts (+/-, 0/ESC)
- Integrated across all media views (feed, publications, activities, routes)

### 8. **Configurable Feed Banner**
- Admin can upload/activate banner image
- Responsive sizing (32vh on desktop, compact on mobile)
- Stored in `configuracion_global` table with JSON config
- Public endpoint (no auth) for quick feed rendering

---

## 📊 Test Coverage

### Backend Tests
- **13 tests** in `test_learning_path.py` — sequential unlocking logic
- **18 tests** in `test_sprint2_backend.py` — motor flag, migrations, tags, banner
- **Run:** `python api/tests/test_learning_path.py`
- **Run:** `python api/tests/test_sprint2_backend.py`

### Frontend Testing
- Manual browser testing verified all 8 features
- Responsive layout tested on desktop/tablet/mobile
- Accessibility: keyboard shortcuts, screen reader compatibility

---

## 📁 Modified/Created Files

### Database & Migrations
- `schema.sql` — New tables & columns (+80 lines)
- `api/database/connection.py` — Migration functions (+25 lines)

### Backend Services (New)
- `api/services/learning_path.py` (250+ lines)
- `api/services/tags.py` (60+ lines)
- `api/services/settings.py` (30+ lines)

### Backend Routes (New)
- `api/routes/learning_path.py` (80+ lines)
- `api/routes/tags.py` (50+ lines)
- `api/routes/settings.py` (40+ lines)

### Backend Modifications
- `api/routes/activities.py` — Rewrite `get_activity()` branching
- `api/services/categories.py` — Add order support
- `api/services/quizzes.py` — Mark new quizzes as 'unificado'
- `api/services/publications.py` — Load tags in responses

### Frontend Pages (New)
- `frontend/src/pages/teacher/RouteManagerPage.jsx` (180+ lines)
- `frontend/src/pages/admin/FeedBannerPage.jsx` (100+ lines)
- `frontend/src/components/media/ImageViewer.jsx` (140+ lines)
- `frontend/src/components/media/ActivityPreview.jsx` (60+ lines)

### Frontend Pages (Modified)
- `frontend/src/pages/my-route/MyRoutePage.jsx` — Complete rewrite
- `frontend/src/pages/activities/ActivityDetailPage.jsx` — Auto-start for Wordwall
- `frontend/src/pages/feed/FeedPage.jsx` — Render banner
- `frontend/src/pages/create/CreatePage.jsx` — Tag selection

### Frontend Components (Modified)
- `frontend/src/components/ui/PostCard.jsx` — Tags display, lightbox
- `frontend/src/components/media/MediaEngine.jsx` — Use ImageViewer
- `frontend/src/services/api.js` — 20+ new functions
- `frontend/src/App.jsx` — New routes
- `frontend/src/components/layout/SideMenu.jsx` — Banner link

---

## 🔄 Backward Compatibility

✅ **All changes are backward compatible:**
- Old databases auto-migrate with `_ensure_*` functions
- Legacy activities continue working without data conversion
- Existing publications appear in both feed and routes if configured
- API versioning not required — new endpoints don't affect old clients

---

## 📝 Database Changes

### New Columns
- `categorias.orden` — order of modules (backfilled automatically)
- `actividades.motor_quiz` — 'legacy' or 'unificado' (backfilled based on quizzes)

### New Tables
- `ruta_pasos` (32 lines) — learning path steps
- `configuracion_global` (8 lines) — global settings (JSON values)
- Note: `etiquetas` and `publicacion_etiquetas` were already in schema; reused

### Migrations
Automatic in `init_db()` via `_ensure_categoria_orden_column()` and `_ensure_actividad_motor_column()`.

---

## 🧪 Verification Checklist

Run through this to verify implementation:

### Student Experience (Anonymous/Student role)
- [ ] Login works
- [ ] `/mi-ruta` shows modules in order
- [ ] First step is AVAILABLE (clickable, teal)
- [ ] Rest are LOCKED (gray candlock icon)
- [ ] Progress bar shows 0/X completed
- [ ] Reading a publication marks it COMPLETED (green checkmark)
- [ ] Next step unlocks to AVAILABLE
- [ ] Clicking image opens lightbox with zoom controls
- [ ] Zoom: +/- buttons work, percentage displays, 0 resets
- [ ] ESC closes lightbox
- [ ] Feed shows tags as chips below description
- [ ] Banner (if admin activated) displays at top of feed
- [ ] Wordwall (single embed block) plays with 1 click from feed

### Teacher Experience (Docente role)
- [ ] `/admin/mi-ruta` shows modules
- [ ] Can add step (modal: type + content selector)
- [ ] Can mark step as optional (obligatorio=false)
- [ ] Can reorder steps with ↑/↓ buttons
- [ ] Can delete step (🗑️)
- [ ] Reorder reflects immediately when student refreshes `/mi-ruta`
- [ ] Optional step doesn't block progression

### Admin Experience (Administrador role)
- [ ] Can access `/admin/banner` settings page
- [ ] Can upload image (or enter URL)
- [ ] Can toggle banner active/inactive
- [ ] Can see preview
- [ ] Changes save to `configuracion_global` table
- [ ] Student feed shows banner (if active)

---

## 🐛 Known Issues

None reported. All 31 tests passing.

---

## 📧 Questions?

Refer to:
- **SPRINT2_CHANGES.md** — detailed phase breakdown
- **API_REFERENCE.md** — endpoint specs and examples
- **CLAUDE.md** — architecture & development guide (in repo)

---

## 📦 Branch Information

- **Branch:** `claude/verify-aula-red-5-blog-ksk0xw`
- **Based on:** Default branch of anntonios1/pauline
- **Status:** Ready for merge/review

---

**Generated:** August 26, 2026  
**Implementation:** Claude Code (Anthropic)  
**Test Coverage:** 31 tests (all passing)

